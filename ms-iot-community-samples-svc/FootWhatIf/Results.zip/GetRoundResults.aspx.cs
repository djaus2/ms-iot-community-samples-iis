﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GetRoundResults : System.Web.UI.Page
{
    //Range of results not in originals results
    const int min = 20;
    const int max = 23;

    //Keys required to get result.
    const string keyname = "Pandora";
    const string keyValue = "137.11";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.HasKeys())
        {
            //Validate key
            if (Request.QueryString["Pandora"] != null)
                if (Request.QueryString["Pandora"] == "137.11")
                {
                    //Get the round requested
                    if (Request.QueryString["Round"] != null)
                        if (Request.QueryString["Round"] != "")
                        {
                            int round;
                            bool res = int.TryParse(Request.QueryString["Round"], out round);
                            if (res)
                            {
                                if ((round >= min) && (round <= max))
                                {
                                    string target = "";
                                    switch (round)
                                    {
                                        case min:
                                            target = "137round20.xml";
                                            break;
                                        case 21:
                                            target = "137round21.xml";
                                            break;
                                        case 22:
                                            break;
                                        case max:
                                            break;
                                    }
                                    if (target != "")
                                        Response.Redirect(target);
                                }
                            }
                        }
                }
        }
        Response.Write("Error");
    }
}